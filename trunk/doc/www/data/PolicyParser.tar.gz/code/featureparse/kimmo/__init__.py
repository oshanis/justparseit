"""
An implementation of the Kimmo two-level morphology algorithm.
"""

from kimmo import *
